/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          primary: "#6AC18D",
          accent: "#6AC18D",
          light: "#f5f5f5",
        }
      },
      fontFamily: {
        sans: ["Sarala", "sans-serif"],
        display: ["Sarala", "sans-serif"],
      }
    },
  },
  plugins: [],
}