import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';

const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    position: "Marketing Director, TechCorp",
    content: "Working with Brandflow transformed our brand identity. Their team understood our vision from day one and delivered beyond our expectations.",
    avatar: "/images/avatar1.jpg" // You'll need to add these images to your public folder
  },
  {
    id: 2,
    name: "Michael Chen",
    position: "Founder, Eco Goods",
    content: "The branding work that Brandflow did for our startup helped us secure venture funding and connect with our target audience. Highly recommended!",
    avatar: "/images/avatar2.jpg"
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    position: "CEO, Fashion Forward",
    content: "Brandflow's photography and digital design services have elevated our online presence. We've seen a 40% increase in engagement since working with them.",
    avatar: "/images/avatar3.jpg"
  }
];

export default function Testimonials() {
  const [current, setCurrent] = useState(0);

  const next = () => {
    setCurrent((current + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrent((current - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="bg-brand-primary text-white py-20">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="section-title">Client Testimonials</h2>
          <p className="text-lg text-gray-300">
            Don't just take our word for it. Here's what our clients have to say.
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <motion.div
            key={current}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="text-center px-4"
          >
            <div className="flex justify-center mb-6">
              <div className="relative w-20 h-20 rounded-full overflow-hidden border-4 border-brand-accent">
                {/* Placeholder for avatar - replace with actual Image component in real implementation */}
                <div className="absolute inset-0 bg-gray-500" />
              </div>
            </div>

            <blockquote className="text-xl md:text-2xl mb-6">"{testimonials[current].content}"</blockquote>

            <div className="mt-4">
              <div className="font-bold text-lg">{testimonials[current].name}</div>
              <div className="text-gray-400">{testimonials[current].position}</div>
            </div>
          </motion.div>

          <div className="flex justify-center mt-8 space-x-4">
            <button 
              onClick={prev}
              className="p-2 rounded-full bg-gray-800 hover:bg-brand-accent transition-colors"
              aria-label="Previous testimonial"
            >
              <FiChevronLeft className="w-6 h-6" />
            </button>
            <button 
              onClick={next}
              className="p-2 rounded-full bg-gray-800 hover:bg-brand-accent transition-colors"
              aria-label="Next testimonial"
            >
              <FiChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}