import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center bg-brand-light">
      <div className="container-custom relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
            We create <span className="text-brand-accent">brands</span> that make an impact
          </h1>
          <p className="text-xl text-gray-700 mb-10 max-w-xl">
            Brandflow is a creative design agency specializing in brand identity, digital experiences, and visual storytelling.
          </p>
          <div className="flex flex-wrap gap-4">
            <a href="#contact" className="btn-primary">
              Start a Project
            </a>
            <a href="#work" className="px-8 py-3 border-2 border-brand-primary rounded-md font-medium hover:bg-brand-primary hover:text-white transition-all">
              See Our Work
            </a>
          </div>
        </motion.div>
      </div>

      {/* Background Pattern */}
      <div className="absolute right-0 bottom-0 w-1/2 h-1/2 opacity-10">
        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
          <path fill="#6AC18D" d="M44.5,-67.3C58.9,-60.9,72.5,-51.1,80.5,-37.5C88.5,-24,90.9,-6.6,87.8,9.5C84.7,25.6,76.2,40.4,65.1,54.2C54,67.9,40.2,80.5,24.7,84.1C9.2,87.8,-7.8,82.3,-24.9,76.6C-42,70.9,-59.1,64.9,-71.4,53.1C-83.6,41.2,-90.9,23.6,-90.7,6.1C-90.5,-11.4,-82.9,-28.9,-72.4,-44.1C-61.8,-59.3,-48.3,-72.3,-33.6,-78.6C-18.9,-84.9,-3.2,-84.6,11.2,-81C25.5,-77.5,50.1,-70.7,64.5,-64.2Z" transform="translate(100 100)" />
        </svg>
      </div>
    </section>
  );
}