import { motion } from 'framer-motion';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative h-96 rounded-lg overflow-hidden">
              {/* Placeholder for team image - replace with actual Image component in real implementation */}
              <div className="absolute inset-0 bg-gray-300" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h2 className="section-title">About Us</h2>
            <p className="text-lg text-gray-600 mb-6">
              Brandflow is a creative design agency founded in 2018. We're a team of passionate designers, strategists, and creatives dedicated to helping brands stand out in today's crowded marketplace.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              Our approach combines strategic thinking with creative execution to deliver brand experiences that connect with your audience and drive business growth.
            </p>

            <div className="grid grid-cols-2 gap-6 mt-10">
              <div>
                <div className="text-4xl font-bold text-brand-accent">50+</div>
                <p className="text-gray-600">Happy Clients</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-brand-accent">120+</div>
                <p className="text-gray-600">Completed Projects</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-brand-accent">12</div>
                <p className="text-gray-600">Team Members</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-brand-accent">6</div>
                <p className="text-gray-600">Years Experience</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}