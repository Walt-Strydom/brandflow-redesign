import { motion } from "framer-motion";

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.15 },
  }),
};

export default function Services() {
  const services = [
    {
      title: "Web Development",
      features: [
        "Custom website development",
        "E‑commerce solutions",
        "CMS integrations",
      ],
      icon: (
        <svg
          className="w-8 h-8"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="4" width="18" height="16" rx="2" ry="2" />
          <line x1="3" y1="10" x2="21" y2="10" />
        </svg>
      ),
    },
    {
      title: "App Development",
      features: [
        "iOS & Android apps",
        "Cross‑platform React Native",
        "Ongoing maintenance",
      ],
      icon: (
        <svg
          className="w-8 h-8"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M11 19a8 8 0 0 1 0-14" />
          <circle cx="12" cy="12" r="3" />
          <path d="M21 12a9 9 0 0 0-17.7-3" />
          <path d="M3 12a9 9 0 0 0 17.7 3" />
        </svg>
      ),
    },
  ];

  return (
    <section id="services" className="py-20 bg-brand-light">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">What we do</h2>
          <div className="w-24 h-1 bg-brand-primary mx-auto" />
        </div>

        <div className="grid gap-10 md:grid-cols-2">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              className="bg-white rounded-xl shadow-lg p-8"
              custom={i}
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <div className="w-14 h-14 bg-brand-primary text-white rounded-full flex items-center justify-center mb-6">
                {service.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
              <ul className="space-y-2">
                {service.features.map((f) => (
                  <li key={f} className="flex items-center text-gray-700">
                    <svg
                      className="w-5 h-5 text-brand-primary mr-2"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8.25 8.25a1 1 0 01-1.414 0l-4.25-4.25a1 1 0 111.414-1.414L8 12.586l7.543-7.543a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}