import Image from 'next/image';
import { useState } from 'react';
import { motion } from 'framer-motion';

// Placeholder projects - in a real implementation you'd replace these with your actual work
const projects = [
  {
    id: 1,
    title: "Eco Cosmetics Rebrand",
    category: "Branding",
    image: "/images/project1.jpg", // You'll need to add these images to your public folder
    description: "Complete brand identity redesign for an organic cosmetics company."
  },
  {
    id: 2,
    title: "Tech Startup Website",
    category: "Web Design",
    image: "/images/project2.jpg",
    description: "Modern, responsive website design for an AI technology startup."
  },
  {
    id: 3,
    title: "Fashion Look Book",
    category: "Photography",
    image: "/images/project3.jpg",
    description: "Creative direction and photography for seasonal fashion catalog."
  },
  {
    id: 4,
    title: "Food Delivery App",
    category: "UI/UX",
    image: "/images/project4.jpg",
    description: "User interface design for popular food delivery service."
  },
  {
    id: 5,
    title: "Coffee Shop Identity",
    category: "Branding",
    image: "/images/project5.jpg",
    description: "Brand identity system for an artisanal coffee chain."
  },
  {
    id: 6,
    title: "Product Packaging",
    category: "Packaging",
    image: "/images/project6.jpg",
    description: "Sustainable packaging design for consumer electronics."
  }
];

const categories = ["All", "Branding", "Web Design", "UI/UX", "Photography", "Packaging"];

export default function Work() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects = activeCategory === "All" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <section id="work" className="py-20 bg-brand-light">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="section-title">Our Work</h2>
          <p className="text-lg text-gray-600">
            Explore our portfolio of projects across various industries and disciplines.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category, index) => (
            <button
              key={index}
              onClick={() => setActiveCategory(category)}
              className={`px-5 py-2 rounded-full transition-all ${
                activeCategory === category 
                  ? 'bg-brand-accent text-white' 
                  : 'bg-white hover:bg-gray-100'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          layout
        >
          {filteredProjects.map((project) => (
            <motion.div
              layout
              key={project.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-lg overflow-hidden shadow-md group"
            >
              <div className="relative h-64 w-full">
                {/* In a real implementation, replace the div below with an actual Image component */}
                <div className="absolute inset-0 bg-gray-300" /> 
                {/* Placeholder for image: 
                <Image 
                  src={project.image} 
                  alt={project.title} 
                  fill 
                  className="object-cover"
                /> */}
              </div>
              <div className="p-6">
                <span className="text-sm text-brand-accent font-medium">{project.category}</span>
                <h3 className="text-xl font-bold mt-2">{project.title}</h3>
                <p className="text-gray-600 mt-2">{project.description}</p>
                <button className="mt-4 text-brand-accent font-medium flex items-center">
                  View Project
                  <svg className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}