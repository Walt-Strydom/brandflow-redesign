import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // or your routing solution
import '../styles/Header.css'; // If you have a separate CSS file

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md fixed w-full z-10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0">
              <img className="h-10" src="/public/images/brandflow-logo.png" alt="BrandFlow" />
            </Link>
          </div>
          <div className="hidden md:flex md:items-center md:space-x-8">
            <Link to="/" className="text-black hover:text-gray-600 px-3 py-2 font-medium">Home</Link>
            <Link to="/#services" className="text-black hover:text-gray-600 px-3 py-2 font-medium">Services</Link>
            <Link to="/about" className="text-black hover:text-gray-600 px-3 py-2 font-medium">About</Link>
            <Link to="/work" className="text-black hover:text-gray-600 px-3 py-2 font-medium">Projects</Link>
            <Link to="/contact" className="text-black hover:text-gray-600 px-3 py-2 font-medium">Contact</Link>
          </div>
          <div className="flex items-center md:hidden">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-black focus:outline-none"
            >
              <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      {/* Mobile menu */}
      <div className={`md:hidden ${mobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1">
          <Link to="/" className="block px-3 py-2 text-black font-medium">Home</Link>
          <Link to="/#services" className="block px-3 py-2 text-black font-medium">Services</Link>
          <Link to="/about" className="block px-3 py-2 text-black font-medium">About</Link>
          <Link to="/work" className="block px-3 py-2 text-black font-medium">Projects</Link>
          <Link to="/contact" className="block px-3 py-2 text-black font-medium">Contact</Link>
        </div>
      </div>
    </header>
  );
};

export default Header;