// src/components/Footer.js
import Link from 'next/link';
import { FiArrowUp } from 'react-icons/fi';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-brand-primary text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold mb-6">Brandflow</h3>
            <p className="text-gray-400 mb-6">
              Creating impactful brand experiences that drive growth and build connections.
            </p>
            <button
              onClick={scrollToTop}
              className="flex items-center text-brand-accent hover:text-white transition-colors"
            >
              <span className="mr-2">Back to top</span>
              <FiArrowUp />
            </button>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#services" className="text-gray-400 hover:text-brand-accent transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link href="#work" className="text-gray-400 hover:text-brand-accent transition-colors">
                  Our Work
                </Link>
              </li>
              <li>
                <Link href="#about" className="text-gray-400 hover:text-brand-accent transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-gray-400 hover:text-brand-accent transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-lg mb-6">Services</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#" className="text-gray-400 hover:text-brand-accent transition-colors">
                  Brand Identity
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-brand-accent transition-colors">
                  Digital Design
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-brand-accent transition-colors">
                  Photography
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-brand-accent transition-colors">
                  Print Design
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-6">Contact Us</h4>
            <div className="space-y-4">
              <p className="text-gray-400">
                123 Design Street<br />
                Creative District<br />
                Cape Town, South Africa
              </p>
              <p className="text-gray-400">
                hello@brandflow.co.za
              </p>
              <p className="text-gray-400">
                +27 12 345 6789
              </p>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 mb-4 md:mb-0">
            © {new Date().getFullYear()} Brandflow. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <Link href="#" className="text-gray-400 hover:text-brand-accent transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="text-gray-400 hover:text-brand-accent transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}