/* Add this to your main CSS file */
@import url('https://fonts.googleapis.com/css2?family=Serif+Sans:wght@400;500;600;700&display=swap'); /* Replace with actual Serif Sans font URL */

:root {
	--primary: #6AC18D;
	--white: #FFFFFF;
	--black: #000000;
}

body {
	font-family: 'Serif Sans', serif, sans-serif;
}

/* Add any additional global styling here */