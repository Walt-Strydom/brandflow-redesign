export default function Contact() {
  return (
    <div className="max-w-4xl mx-auto py-16 px-4">
      <h1 className="text-3xl font-bold text-primary mb-6">Contact Us</h1>
      <p className="text-gray-700 mb-4">
        Let’s build something great together.
      </p>
      <a
        href="mailto:hello@brandflow.dev"
        className="inline-block bg-primary text-white px-6 py-2 rounded hover:bg-opacity-90 transition"
      >
        Email us at hello@brandflow.dev
      </a>
    </div>
  );
}
