export default function About() {
  return (
    <div className="max-w-4xl mx-auto py-16 px-4">
      <h1 className="text-3xl font-bold text-primary mb-6">About BrandFlow</h1>
      <p className="text-gray-700 mb-4">
        BrandFlow builds clean and modern web & app solutions. We don’t do
        templates—we do custom.
      </p>
      <p className="text-gray-700">
        Whether you're launching a new brand or refreshing your digital
        presence, we deliver fast, reliable, and scalable products.
      </p>
    </div>
  );
}
